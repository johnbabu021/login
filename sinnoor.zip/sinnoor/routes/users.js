const { response } = require('express');
var express = require('express');
const { USER_COLLECTION } = require('../config/collection');
var router = express.Router();
const userHelper=require('../helpers/user-helpers')

/* GET users listing. */
router.get('/', function(req, res, next) {
  let user=req.session.user
  res.render('user/index',{user})
});
router.get('/signup',(req,res)=>{
  res.render('user/signup')
})

router.post('/signup',(req,res)=>{
userHelper.doSignup(req.body).then((response)=>{
  console.log(response)
})

})


router.get('/login',(req,res)=>{
  res.render('user/login')
})

router.post('/login',(req,res)=>{

  userHelper.doLogin(req.body).then((response)=>{
    if(response.status){

      req.session.loggedIn=true
      req.session.user=response.user
      res.redirect('/')

    }
    else{
      res.redirect('/login')
    }
  })
})

module.exports = router;
