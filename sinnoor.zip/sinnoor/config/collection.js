module.exports={
    USER_COLLECTION:'user'

}